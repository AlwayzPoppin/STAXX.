
import { GoogleGenAI, Type, GenerateContentResponse, Modality } from "@google/genai";
import { Transaction, TransactionCategory, WorkerType, FilingStep, UserProfile } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Extract and parse IRS tax form data from images
export const analyzeTaxDocument = async (base64Image: string, docType: string): Promise<any> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
        { text: `This is a ${docType} tax document. Extract all relevant IRS fields (EIN, Employer Name, Wages, Federal Tax Withheld, etc) into a clean JSON format.` }
      ],
    },
    config: { responseMimeType: "application/json" }
  });
  try { return JSON.parse(response.text || '{}'); } catch { return {}; }
};

// Categorize a specific transaction description for professional tax filing
export const categorizeTransaction = async (description: string, amount: number, workerType: WorkerType): Promise<any> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Categorize this transaction for a ${workerType} professional: Description: "${description}", Amount: $${amount}.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          category: { 
            type: Type.STRING,
            description: "Categorize as: INCOME, MILEAGE, PLATFORM_FEES, BUSINESS_EQUIPMENT, HOME_OFFICE, COMMUNICATIONS, MARKETING, W2_WITHHOLDING, or OTHER"
          },
          isDeductible: { type: Type.BOOLEAN },
          aiNotes: { type: Type.STRING }
        },
        required: ["category", "isDeductible"]
      }
    }
  });
  try { return JSON.parse(response.text || '{}'); } catch { return { category: 'OTHER', isDeductible: false }; }
};

// Automated receipt scanning and categorization
export const analyzeReceipt = async (base64Image: string, workerType: WorkerType): Promise<Partial<Transaction>> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
        { text: `Extract information from this receipt for a user who works as a ${workerType}. Find the store, date, total, and categorize it based on IRS Schedule C categories if applicable.` },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          description: { type: Type.STRING },
          amount: { type: Type.NUMBER },
          date: { type: Type.STRING },
          category: { type: Type.STRING },
          isDeductible: { type: Type.BOOLEAN },
          aiNotes: { type: Type.STRING }
        },
        required: ["description", "amount", "date", "category", "isDeductible"]
      },
    },
  });
  try { return JSON.parse(response.text || '{}'); } catch (e) { return {}; }
};

// Professional tax advisor with real-time web grounding via Google Search
export const getTaxAdvice = async (query: string, context: string, workerType: WorkerType): Promise<{text: string, sources?: any[]}> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `User Info: ${workerType} professional. Context: ${context}. Question: ${query}. Instructions: You are a Lead Tax Strategist. Provide real-time advice grounded in 2024 tax code.`,
    config: { tools: [{ googleSearch: {} }], temperature: 0.4 }
  });
  return { 
    text: response.text || "Connection lost.", 
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks 
  };
};

// Accessibility audio for hands-free tax navigation
export const generateSpeech = async (text: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Tax assistant: ${text}` }] }],
    config: { 
      responseModalities: [Modality.AUDIO], 
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } } 
    },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
};

// Context-aware filing guide for manual tax form completion
export const guideFiling = async (step: FilingStep, transactions: Transaction[], workerType: WorkerType, userResponse?: string, currentProfile?: UserProfile | null): Promise<any> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Filing Step: ${step}. Role: ${workerType}. User Profile: ${JSON.stringify(currentProfile)}. Message: "${userResponse || 'Start'}". Guide the user through providing legal tax information.`,
    config: { 
      temperature: 0.1, 
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          text: { type: Type.STRING },
          profileUpdate: { type: Type.OBJECT, properties: { name: { type: Type.STRING }, ssn: { type: Type.STRING }, filingStatus: { type: Type.STRING } } }
        }
      }
    }
  });
  try { return JSON.parse(response.text || '{"text": "Refining data..."}'); } catch { return { text: "Error." }; }
};

// Structural JSON generator for IRS form layouts
export const generateFormDraft = async (transactions: Transaction[], workerType: WorkerType, lastMessage?: string): Promise<any> => {
  const ledgerData = transactions.map(t => ({ desc: t.description, amt: t.amount, cat: t.category, ded: t.isDeductible }));
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a full tax return draft including Form 1040, and if the user is GIG, generate Schedule C and Schedule SE data. Data: ${JSON.stringify(ledgerData)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          forms: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                sections: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      label: { type: Type.STRING },
                      lines: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { lineId: { type: Type.STRING }, description: { type: Type.STRING }, amount: { type: Type.NUMBER } } } }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  });
  try { return JSON.parse(response.text || '{}'); } catch { return null; }
};

// Identify tax saving opportunities from financial ledger
export const suggestOptimizations = async (transactions: Transaction[], workerType: WorkerType): Promise<string[]> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Suggest 3 tax strategies: ${JSON.stringify(transactions)}`,
    config: { responseMimeType: "application/json", responseSchema: { type: Type.ARRAY, items: { type: Type.STRING } } }
  });
  try { return JSON.parse(response.text || '[]'); } catch { return ["Keep track of mileage."]; }
};